#include <bits/stdc++.h>
using namespace std;

int main() {
    int n;
    cin>>n;
    int *a=new int[n];
    for(int i=0;i<n;i++)
    cin>>a[i];
    
    int *b=new int[n];
    b[0]=-1;
    
    for(int j=1;j<n;j++)
    {
        int k=j-1;
        while(k>=0 && a[k]<a[j]) k=b[k];

        b[j]=k;
        
    }
    
    int *d=new int[n];
    d[n-1]=n;
    
    for(int j=n-2;j>=0;j--)
    {
        int k=j+1;
        while(k<n && a[k]<a[j])k=d[k];
        d[j]=k;
        
    }
    for(int i=0;i<n;i++)
    cout<<(i-b[i])*(d[i]-i)<<" ";
        
    cout<<"\n";
    delete[] b;
    delete[] d;
    
    

	return 0;
}
