#include<bits/stdc++.h>
using namespace std;
const int limit_value=1001000;
const int infinity=1e9;

vector<vector<pair<int,int>>> undirected_graph(2*limit_value+3);

void addEdge(int a, int b) 
{ 
    undirected_graph[2*a].push_back({2*b+1,1});
    undirected_graph[2*a+1].push_back({2*b,1});
    undirected_graph[2*b].push_back({2*a+1,1});
    undirected_graph[2*b+1].push_back({2*a,1});
}

void small_dist(int s, vector<int> & vect) 
{
    int n = undirected_graph.size();
    vect.assign(n, infinity);
    vect[s] = 0;

    using pii = pair<int, int>;

    priority_queue<pii, vector<pii>, greater<pii>> que;
    que.push({0, s});

    while (!que.empty()) 
    {
        int v = que.top().second;
        int d_v = que.top().first;
        que.pop();

        if (d_v != vect[v])
            continue;

        for (auto e : undirected_graph[v]) 
        {
            int to = e.first;
            int len = e.second;

            if (vect[v] + len < vect[to])
            {
                vect[to] = vect[v] + len;
                que.push({vect[to], to});
            }
        }
    }
}

int main()
{	
	ios_base::sync_with_stdio(false);
    cin.tie(NULL);

	int n,m,u,v,c1,c2;
	cin>>n>>m>>u>>v;
	
	for(int i=0;i<m;i++)
	{
		cin>>c1>>c2;
		addEdge(c1,c2);
	}
	vector<int> dist;
	vector<int>distance_u;
	small_dist(2*u,distance_u);

	if(distance_u[2*v]==infinity)
	{
		cout<<"impossible"<<endl;
	}

	else
	{	int val=distance_u[2*v]/2;
		cout<<"possible"<<endl;
		cout<<val<<endl;

		vector<int>distance_v;
		small_dist(2*v,distance_v);
		vector<int>storage;

		for(int i=0;i<n;i++)
		{
			if(distance_u[2*i+1]==distance_v[2*i+1])
			{
				if(distance_u[2*i+1]==val)
				{cout<<i<<" ";
				continue;
				}

			}

			if(distance_v[2*i+1]==distance_u[2*i])
			{
				if(distance_v[2*i+1]==val)
				{cout<<i<<" ";
				continue;
				}
			}

			if(distance_u[2*i+1]==distance_v[2*i])
			{
				if(distance_u[2*i+1]==val)
				{cout<<i<<" ";
				continue;
				}
			}

			if(distance_v[2*i]==distance_u[2*i])
			{
				if(distance_u[2*i]==val)
				{cout<<i<<" ";
				continue;
				}
			}

		}
		cout<<endl;

	}
	
	return 0;
}