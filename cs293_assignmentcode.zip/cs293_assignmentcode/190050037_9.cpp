#include <bits/stdc++.h>
using namespace std;

#define ll long long 
#define pb push_back
#define all(x) (x).begin(), (x).end()
#define MOD 1000000007

bool comp(array<ll, 3> a1, array<ll, 3> a2) {
	return a1[1] < a2[1];
}

struct Pair {
	int P, S, Idx;
	bool operator<(const Pair& t) const { return S <= t.S; }
};

int main() {
	int N;
	cin >> N;
	vector<multiset<Pair>> v[2];
	bool unique = 1;
	vector<Pair> T1[2];
	for (int row = 0; row < 2; row++) {
		vector<Pair> T(N);
		T1[row].resize(N);
		for (int i = 0; i < N; i++) cin >> T[i].P, T1[row][i].P = T[i].P;
		for (int i = 0; i < N; i++) cin >> T[i].S, T1[row][i].S = T[i].S;
		for (int i = 0; i < N; i++) T[i].Idx = i + 1;
		sort(T.begin(), T.end(), [] (const Pair & a, const Pair & b) -> bool { return a.P < b.P; });
		for (int i = 0; i < N; i++) {
			if (i == 0 || T[i - 1].P != T[i].P) v[row].emplace_back();
			v[row].back().insert(T[i]);
		}
	}

	// for (int i = 0; i < 2; ++i) {
	// 	for (auto x: v[i]) {
	// 		for (auto y: x) {
	// 			cout << y.P << " " << y.S << " " << y.Idx << "\n";
	// 		}cout << endl;
	// 	}
	// }

	vector<int> ret[2];
	bool flag = 1;
	for (int idx1 = 0, idx2 = 0; ret[0].size() < N; ) {
		if (v[0][idx1].size() < v[1][idx2].size()) {

			for (auto const& t : v[0][idx1]) {
				auto it = v[1][idx2].upper_bound(Pair{t.P, t.S - 1, t.Idx});
				if (it == v[1][idx2].begin()) {
					flag = 0;
					break;
				}
				--it;
				ret[0].push_back(t.Idx);
				ret[1].push_back(it -> Idx);
				v[1][idx2].erase(it);
			}
			idx1++;
		}
		else {
			for (auto const& t : v[1][idx2]) {
				auto it = v[0][idx1].upper_bound(t);
				if (it == v[0][idx1].end()) {
					flag = 0;
					break;
				}
				ret[1].push_back(t.Idx);
				ret[0].push_back(it -> Idx);
				v[0][idx1].erase(it);
			}
			idx2++;
			if (v[0][idx1].size() == 0) idx1++;
		}
		if (!flag) {
			break;
		}
	}

	if (!flag) {
		cout << "impossible\n";
		return 0;
	}

	vector<int> ans1(N), ans2(N);
	for (int row = 0; row < 2; row++) {
		for (int i = 0; i < ret[row].size(); i++) {
			if (i) cout << ' ';
			cout << ret[row][i];
			if (row == 0) ans1[i] = ret[row][i];
			else ans2[i] = ret[row][i];
		}
		cout << endl;
	}

	bool u = 1;
	for (int i = 0; i < N - 1; ++i) {
		if (T1[0][ans1[i]].P == T1[0][ans1[i + 1]].P || T1[1][ans2[i]].P == T1[1][ans2[i + 1]].P) {
			if (T1[0][ans1[i]].S >= T1[1][ans2[i + 1]].S && T1[0][ans1[i + 1]].S >= T1[1][ans2[i]].S) {
				u = 0;
				break;
			}
		}
	}

	if (u) {
		cout << "unique\n";
	}
	else cout << "not unique\n";

}

