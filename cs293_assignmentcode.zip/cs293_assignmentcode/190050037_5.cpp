#include<bits/stdc++.h>
using namespace std;
typedef long long int ll;
void fun(ll a[],ll ans[],int start,int end)
{
    if((start+1)==end)
    ans[start]=a[start];
    else
    {
        int n=end-start;
        fun(a,ans,start,start+(n/2));
        fun(a,ans,start+(n/2),end);
        for(int i=(start+(n/2));i<end;i++)
        ans[i]+=ans[(i-(n/2))];
    }
}

int main()
 {
    int n;
    cin>>n;
    int val=pow(2,n);
    ll arr1[val],arr2[val];
    for(int i=0;i<val;i++)
    cin>>arr1[i];
    
    for(int i=0;i<val;i++)
    cin>>arr2[i];
    
    long long int f[val];
    fun(arr1,f,0,val);
    for(int i=0;i<val;i++)
    cout<<f[i]<<" ";
    cout<<"\n";

  }
