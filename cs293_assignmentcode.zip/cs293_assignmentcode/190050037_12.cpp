#include<bits/stdc++.h>
using namespace std;

int main()
{
	int n,m;
	cin>>n>>m;
	int a,b,z;
	vector<set<int>>v(n);
	queue<int>q;

	for(int i=0;i<m;i++)
	{
		cin>>a>>b;
		if(v[a].size()!=0)
		{	//cout<<a<<" "<<"called"<<"\n";
			if(v[a].find(b)==v[a].end())
			{
				v[a].insert(b);
				v[b].insert(a);
			}
		}
		else
		{
			v[a].insert(b);
			v[b].insert(a);
		}
	}

	for(int i=0;i<n;i++)
	{
		if(v[i].size()<=2 && v[i].size()>0)
			q.push(i);
	}
	

	std::set<int>::iterator it;
	/*while (!q.empty()) { 
        cout << ' ' << q.front(); 
        q.pop(); 
    } */
    
	while(q.size()>1)
	{
		z=q.front();

		if(v[z].size()==1)
		{	
			//cout<<z<<"\n";
			int k=*v[z].begin();
			v[z].erase(*v[z].begin());
			v[k].erase(z);
			if(v[k].size()==2)
				q.push(k);

		}

		else if(v[z].size()==2)
		{
			it=v[z].begin();
			int k1=*it;
			it++;
			int k2=*it;
			v[z].clear();
			v[k1].erase(z);
			v[k2].erase(z);

			if(v[k1].find(k2)==v[k1].end())
			{
				v[k1].insert(k2);
				v[k2].insert(k1);

			}

			else
			{
				if(v[k1].size()==2)
					q.push(k1);
				if(v[k2].size()==2)
					q.push(k2);
			}
		}
		q.pop();

	}
	
	int flag=1;
	for(int i=0;i<n;i++)
	{	
		//cout<<v[i].size()<<"\n";
		if(v[i].size()>=3)
		{
			flag=0;
			break;
		}
	}

	if(flag==1 && q.size()<=1)
		cout<<"yes"<<"\n";
	else
		cout<<"no"<<"\n";



	return 0;
}