#include <iostream>
using namespace std;
typedef long long int ll;
ll func(ll n, int k) {
    if(n == 1)
    	return 0;
    if(k == 1)
    	return n-1;
    if(k > n)
    	return (func(n-1, k) + k) % n;
    
    ll val = func(n - n/k, k);
    val-= n % k;
    if (val < 0)
        val+= n;
    else
        val += val/(k - 1);
    return val;
}
int main() {
    ll n;
    int k;
    cin>>n>>k;
    cout<<func(n,k)+1;
    return 0;
}