#include <bits/stdc++.h>
using namespace std;

int main() 
{
	ios::sync_with_stdio(0);
	cin.tie(0);

	int n_c,n_s,max_c,t;
	cin>>n_c>>n_s>>max_c>>t;

	map<string,array<int,2>> c;
	map<string,set<string>> s_c;
	map<string,set<string>> c_s;
	map<string,set<int>> s_s;

	for(int i=0;i<n_c;i++)
	{
	string a;
	int n1,n2;
	cin>>a>>n1>>n2;
	c[a]={n1,n2};
	s_c[a]={};
	}

	for(int i=0;i<n_s;i++)
	{
	string a;
	cin>>a;
	c_s[a]={};
	s_s[a]={};
	}


	while(t--)
	{
		char o;
		cin>>o;
		if(o=='R')
		{
		  string r,Cor;
		  cin>>r>>Cor;
		  if((c[Cor][1]!=-1)&&(s_c[Cor].size()==c[Cor][1]))
		  {
				cout<<"fail"<<endl;
				continue;
		  }
		  if(c_s[r].size()>=max_c)
		  {
			cout<<"fail"<<endl;
			continue;
		  }
		  if(find(s_s[r].begin(),s_s[r].end(),c[Cor][0])!=s_s[r].end())
		  {
			cout<<"fail"<<endl;
			continue;
		  }
		  cout<<"success"<<endl;
		  c_s[r].insert(Cor);
		  s_c[Cor].insert(r);
		  s_s[r].insert(c[Cor][0]);
		}
		else if(o=='D')
		{
		string r,Cor;
		cin>>r>>Cor;
		auto it=c_s[r].find(Cor);
		if(it==c_s[r].end())
		{
			cout<<"fail"<<endl;
			continue;
		}
		cout<<"success"<<endl;
		c_s[r].erase(it);
		s_c[Cor].erase(s_c[Cor].find(r));
		s_s[r].erase(s_s[r].find(c[Cor][0]));
		}
		else if(o=='P')
		{
		string str;
		getline(cin, str);
		str=str.substr(1,str.size()-1);
		if(str.size()==6)
		{
			for(auto x:s_c[str])
			cout<<x<<" ";

			cout<<endl;
		}
		
		else if(str.size()==13)
		{
			string Cor1=str.substr(0,6),Cor2=str.substr(7,6);
			map<string,bool> p;
			for(auto x:s_c[Cor1])
            p[x] = true;
				
			for(auto x:s_c[Cor2])
			{
			 if(p[x]==true)
			 cout<<x<<" ";
					
			}
			cout<<endl;
		}
		else if(str.size()==9)
		{
		 for(auto x:c_s[str])
		 cout<<x<<" ";

		 cout<<endl;
		}
		else if(str.size()==19)
		{
		 string s1=str.substr(0, 9),s2=str.substr(10, 9);
		map<string,bool> p;

		for(auto x:c_s[s1])
		p[x]=true;
				
		for(auto x:c_s[s2])
		{
			if(p[x]==true)
			cout<<x<<" ";
					
		}

		cout<<endl;
		}
		

		}
	}
	return 0;
}

