#pragma GCC optimize("O3")
#include <bits/stdc++.h>
using namespace std;
int func(string s,int k)
{   int counter=0;
    int siz=s.size()/k; //size of each block
    int arr[siz][26]={0};       // k is number of block
    for(int i=0;i<k;i++)
    {
        for(int j=0;j<siz;j++)
        arr[j][s[i*siz+j]-'a']++;
    }
    for(int i=0;i<siz;i++)
    counter+=k-*max_element(arr[i],arr[i]+26);
    return counter;
    
}

int main() {
	ios_base::sync_with_stdio(false);
	 cin.tie(NULL);
    string s;
    int k;
    cin>>s;
    cin>>k;
    cout<<func(s,k)<<"\n";
    long int counter=s.size();
    long int k_val=1;
    for(int c=1;c<=s.size()-1;c++)
    {   int arr[c][26]={0};
        long int temp_counter=0;
        for(int i=0;i<ceil(1.0*s.size()/c);i++)
        {
            for(int j=0;j<c && (i*c+j)<s.size();j++)
            arr[j][s[i*c+j]-'a']++;
        }
        
        if(s.size()%c==0)
        {
        for(int i=0;i<c;i++)
        temp_counter+=s.size()/c-*max_element(arr[i],arr[i]+26);
        }
        else
        {
            for(int i=0;i<c;i++)
            temp_counter+=1+s.size()/c-*max_element(arr[i],arr[i]+26);
        }
        
        if(temp_counter<=counter)
        {
            counter=temp_counter;
            k_val=c;
        }
        
    }
    cout<<counter<<" "<<ceil(s.size()*1.0/k_val);
    
    
	// your code goes here
	return 0;
}
