#include<bits/stdc++.h>
using namespace std;

struct point
{
	point *l,*r;
	char op;
};

point* create(char ch)
{
	point *node=new point();
	node->op=ch;
	node->l=node->r=NULL;
	return node;
}

point *make_string_tree(string str)
{
	stack<point*> tree_stack;
	point *t1,*t2,*t;
	for(int i=0;i<str.size();i++)
	{
		if(str[i]=='+'||str[i]=='*')
		{
			t1=tree_stack.top();
			tree_stack.pop();
			t2=tree_stack.top();
			tree_stack.pop();
			point *t=create(str[i]);
			t->l=t2;
			t->r=t1;
			tree_stack.push(t);
		}

		else 
		{
			t=create(str[i]);
			tree_stack.push(t);
		}
	}

	return tree_stack.top();
}

array<int,2> min_opr(point *root)
{
    if(root->op=='e')
        return {0,0};
    
    array<int,2> l=min_opr(root->l);
    array<int,2> r=min_opr(root->r);

    if(root->l->op=='e'&&root->r->op=='e')
        return {1,1};
    
    else if(root->r->op=='e')
    {
        if(root->op==root->l->op)
            return {l[0]+r[0],max(l[1],r[1]+1)};
        
        else
            return {l[0]+r[0]+1,max(l[1]+1,r[1]+1)};
        
    }

    else if(root->l->op=='e')
    {
        if(root->op==root->r->op)
            return {l[0]+r[0],max(l[1]+1,r[1])};
        
        else
            return {l[0]+r[0]+1,max(l[1]+1,r[1]+1)};
        
    }

    else if(root->r->op==root->l->op)
    {
        if(root->r->op==root->op)
            return {l[0]+r[0]-1,max(l[1],r[1])};
        
        else
            return {l[0]+r[0]+1,max(l[1]+1,r[1]+1)};
        
    }

    else
    {
        if(root->r->op==root->op)
            return {l[0]+r[0],max(l[1]+1,r[1])};
        
        else
            return {l[0]+r[0],max(l[1],r[1]+1)};
        
    }

}

int main() 
{
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);

	string s; 
	cin >> s;

	point *root = make_string_tree(s);
	array<int, 2> arr = min_opr(root);

	cout << arr[0] << " " << arr[1] << endl;
	return 0;
}
