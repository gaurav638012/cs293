#include <bits/stdc++.h>
using namespace std;
void app(int a[],int p,int k)
{
    
    int store=a[p];
    a[p]=0;
    for(int i=0;i<k;i++)
    a[i]+=store/k;
    for(int i=0;i<store%k;i++)
    a[(p+1+i)%k]++;
}

int main() 
{

    int n,k;
    cin>>n>>k;
    int arr[k];
    for(int i=0;i<n;i++)
    cin>>arr[i];
    vector<int> v;
    int miner=*min_element(arr, arr + k);
    int maxer=*max_element(arr, arr + k);
    
    if(!((maxer-miner) <= 1))
    {  int ptr=k-1;int flag=0;
        while(arr[0]!=n)
        {
            if(arr[ptr]+ptr>=k)
            {
                flag=1;
                app(arr,ptr,k);
                v.push_back(ptr);
                if(ptr==1)
                {
                    flag=0;
                    ptr=k-1;
                }
                else
                ptr--;
            }
            else if(flag==0 && ptr==1)
            {
                while(arr[ptr]+ptr<k)
                {
                    app(arr,ptr,k);
                    v.push_back(ptr);
                    ptr++;
                }
                ptr=k-1;
                
            }
            else if(ptr==1)
            {
                flag=0;
                ptr=k-1;
            }
            else
            ptr--;
        }
    
     for(int i=0;i<v.size();i++)
     cout<<v[i]<<" ";
     cout<<0;
    
    }
    
    return 0;
}