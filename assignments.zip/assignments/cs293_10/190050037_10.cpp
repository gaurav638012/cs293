#pragma GCC optimize("O3")
#include<bits/stdc++.h>
#include <bitset>
using namespace std;
int find_no(int j) //working
{
	int count = 0; 
	while (j) { 
        count += j & 1; 
        j >>= 1; 
    } 
    return count; 
}
string to_str(int k,int n) //working
{
    string s1(n,'0');
    int count=0;
    while(k)
    {   
        int z=(k & 1);
        if(z==1)
            s1[n-1-count]='1';
        else
            s1[n-1-count]='0';
        k>>=1;
        count++;
    }
    return s1;
}
void set_arr(int a[],int n) //working
{
	for(int i=0;i<n;i++)
		a[i]=i;
}
string permutate(string s,int a[],int n) //working
{
	string s1(n,'0');
	for(int i=0;i<n;i++)
		s1[a[i]]=s[i];
	return s1;
}

int main()
{  
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	int n,m;
	cin>>n>>m;
	string s[m];
	map<int, map<string, vector<int> > >v;
	int arr[n];
	set_arr(arr,n);

	for(int i=0;i<m;i++)
	{
		cin>>s[i];
		vector<int>temp;
		int counter=0;
		for(int j=0;j<pow(2,n);j++)
		{
			if(s[i][j]=='1')
			{
				counter++;
				temp.push_back(find_no(j));
			}
		}

		if(v.find(counter)==v.end())
			v[counter]=std::map<string,vector<int>>();

		sort(temp.begin(),temp.end());
		string temp1;

		for(auto x:temp)
			temp1.push_back(char(x));

		if(v[counter].find(temp1)==v[counter].end())
		{
			v[counter][temp1]=std::vector<int>();
		}
		v[counter][temp1].push_back(i);

	}

	map<int, map<string,vector<int> > >::iterator it;
	int ans=0;
	map<string,vector<int>>::iterator ot;
	for(it=v.begin();it!=v.end();it++)
	{
		for(ot=it->second.begin();ot!=it->second.end();ot++)
		{
			vector<int>tempo;
						
			for(auto i:ot->second)
			{	int flag=0;
				for(auto j:tempo)
				{
					do
					{   int flag1=1;
						for(int k=0;k<pow(2,n);k++)
						{
							std::string temp_s = to_str(k,n);
							temp_s=permutate(temp_s,arr,n);
							int val=stoi(temp_s,0,2);
							if(s[j][k]!=s[i][val])
							{
								flag1=0;
								break;
							}

						}
						if(flag1==1)
						{
							flag=1;
							break;
						}

					}while(next_permutation(arr, arr + n));
					set_arr(arr,n);

					if(flag==1)
					{
						break;
					}
				}
				if(flag==0)
					tempo.push_back(i);
			}
			ans+=tempo.size();
		}
	}
	cout<<ans;

return 0;
}