#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;
ll store[20][20];
 
ll ranker(int arr[],int n) {
	ll val = 0;
	int maxer = 0;
	for (int i = 1; i < n;i++) {
		maxer = max(maxer, arr[i - 1]);
		val += arr[i] * store[maxer][i];
	}
	return val;
}
void print_vec(vector<int>v)
{
	for(int i=0;i<v.size();i++)
		cout<<v[i]<<" ";
	cout<<"\n";
}


vector<int> given_rank(ll rank,int n) {
	rank+=1;
	vector<int> arr(n,0);
	arr[0] = 0;
	int maxer = 0;
	for (int i = 1; i < n; ++i) {
		ll summer = 0; int flag = 0;
		for (int j = 0; j <= maxer; ++j) {
			if (summer + store[maxer][i] >= rank) {
				flag = 1;
				arr[i] = j;
				break;
			}
			summer += store[maxer][i];
		}
		
		if (flag == 0) 
		    arr[i] = maxer + 1;
		    
		maxer = max(maxer, arr[i]);
		rank -= summer;
	}
	return arr;
}
int main()
{  ios::sync_with_stdio(0);
   cin.tie(0);
   int t,n;
   cin>>n>>t;
   for(int i=0;i<20;i++)
   {
       for(int j=0;j<20;j++)
       store[i][j]=0;
   }
    // first index m ,second one is l  
                  // l goes from 1 to n and m goes from 0,n-1
   for(int i=n-1;i>=0;i--)
    store[i][n-1]=1;
   for(int i=n-2;i>=0;i--)
   {
       for(int j=i;j>=0;j--)
      	store[j][i]=store[j][i+1]*(j+1)+store[j+1][i+1];
       
   }

   	
   for(int i=0;i<t;i++)
    {
   	char ch;
   	cin>>ch;
   	if(ch=='R')
   	{
           int arr[n];
			for (int i = 0; i < n; ++i)
			cin >> arr[i];
			
			cout << ranker(arr,n) << "\n";
   	}
   	else
   	{
      ll z;
      cin>>z;
      print_vec(given_rank(z,n));

   	}
   }

   return 0;
}