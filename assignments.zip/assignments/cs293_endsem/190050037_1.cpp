#include<bits/stdc++.h>
using namespace std;

int main()
{
	
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);

	int n;
	int flag=0;
	cin>>n;
	int a[n];
	int store[n]={0};

	

	for(int i=0;i<n;i++)
	{cin>>a[i];
	 store[a[i]]++;
	 
	}

	int large=store[0];
	for(int i=1;i<n;i++)
	{
		if(store[i]>large)
			large=store[i];
	}

	if(large>n/2)
	{cout<<n<<endl;
	 
	}

	
	else
	{
	
	cout<<2*large-1<<endl;
	}




	


	




	return 0;
}
