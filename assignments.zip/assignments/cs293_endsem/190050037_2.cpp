
#include<bits/stdc++.h>
using namespace std;
typedef long long int ll;

struct et
{
    char value;
    int v_count=0;
    et* left, *right;
};

bool isOperator(char c)
{
    if (c == '1' || c == '0')
        return true;

    return false;
}

// Utility function to do inorder traversal
/*
void inorder(et *t)
{
    if(t)
    {
        inorder(t->left);
        printf("%c ", t->value);
        inorder(t->right);
    }
}*/
 
// A utility function to create a new node
et* newNode(char v)
{
    et *temp = new et;
    
    temp->left = temp->right = NULL;
    temp->value = v;
    return temp;
};
 
// Returns root of constructed tree for given
// postfix expression
et* constructTree(string postfix)
{
    stack<et *> st;
    et *t, *t1, *t2;
 
    // Traverse through every character of
    // input expression
    for (int i=0; i<postfix.size(); i++)
    {
        // If operand, simply push into stack
        if (!isOperator(postfix[i]))
        {
            t = newNode(postfix[i]);
            t->v_count=1;
            st.push(t);
        }
        else // operator
        {
            t = newNode(postfix[i]);
 
            // Pop two top nodes
            t1 = st.top(); // Store top
            st.pop();      // Remove top
            t2 = st.top();
            st.pop();
 
            //  make them children
            t->right = t1;
            t->left = t2;
            t->v_count=t1->v_count+t2->v_count;
 
            // Add this subexpression to stack
            st.push(t);
        }
    }
 
    //  only element will be root of expression
    // tree
    t = st.top();
    st.pop();
 
    return t;
}

ll find_val(et* tree)
{
	if(tree->value=='e')
		return 0;
	else if(tree->value=='0')
	{
		return find_val(tree->left)+find_val(tree->right);
	}
	else
	{
		return find_val(tree->left)+find_val(tree->right)+tree->left->v_count*tree->right->v_count;
	}
}

ll max_length(et* tree)
{
	if(tree->value=='e')
		return 0;
	else if(tree->value=='0')
		return max(max_length(tree->left),max_length(tree->right));
	else
		return max_length(tree->left)+max_length(tree->right)+1;

}

int main()
{
    string postfix;
    cin>>postfix;
    et* r = constructTree(postfix);
    cout<<find_val(r)<<endl;
    //cout<<max_length(r);
    
    return 0;
}